package com.example.choinapatryk.pgm;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button LA = (Button) findViewById(R.id.LA);

    Button LB = (Button) findViewById(R.id.LB);

    Button RA = (Button) findViewById(R.id.RA);

    Button RB = (Button) findViewById(R.id.RB);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
